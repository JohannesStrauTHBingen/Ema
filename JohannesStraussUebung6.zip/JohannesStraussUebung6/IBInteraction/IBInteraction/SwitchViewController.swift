//
//  SwitchViewController.swift
//  IBInteraction
//
//  Created by Student on 26.05.17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class SwitchViewController: UIViewController {
    
    
    @IBOutlet weak var flipper: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if flipper.isOn{
            self.view.backgroundColor = .green
        }else{
            self.view.backgroundColor = .red
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func flip(_ sender: Any) {
        if flipper.isOn{
            self.view.backgroundColor = .green
        }else{
            self.view.backgroundColor = .red
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
