//
//  StepperViewController.swift
//  IBInteraction
//
//  Created by Student on 26.05.17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class StepperViewController: UIViewController {


    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var value: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        value.text = String(stepper.value)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func steping(_ sender: Any) {
        value.text = String(stepper.value)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
