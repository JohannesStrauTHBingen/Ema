//
//  ViewControllerB.swift
//  Recognizer
//
//  Created by Student on 30.05.17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ViewControllerB: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTouch))
        
        view.backgroundColor = .red
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
    func onTouch(){
        print("Don't touch me!")
        dismiss(animated: true, completion: nil)
    }
}
